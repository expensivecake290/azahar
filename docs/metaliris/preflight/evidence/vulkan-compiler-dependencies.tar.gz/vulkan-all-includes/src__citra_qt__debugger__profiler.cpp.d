translation-unit: \
  /Applications/Xcode-beta.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX27.0.sdk/SDKSettings.json \
  /tmp/metaliris-gate0-84oi2too/source/src/citra_qt/debugger/profiler.cpp
